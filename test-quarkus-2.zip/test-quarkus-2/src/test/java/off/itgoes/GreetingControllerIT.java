package off.itgoes;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
class GreetingControllerIT extends GreetingControllerTest {
    // Execute the same tests but in packaged mode.
}
